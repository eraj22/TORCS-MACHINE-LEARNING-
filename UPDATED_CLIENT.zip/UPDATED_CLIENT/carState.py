'''
Enhanced Car State with utility methods for better analysis
'''
import msgParser
import math

class CarState(object):
    '''
    Enhanced class that holds all the car state variables with utility methods
    '''

    def __init__(self):
        '''Constructor'''
        self.parser = msgParser.MsgParser()
        self.sensors = None
        self.angle = None
        self.curLapTime = None
        self.damage = None
        self.distFromStart = None
        self.distRaced = None
        self.focus = None
        self.fuel = None
        self.gear = None
        self.lastLapTime = None
        self.opponents = None
        self.racePos = None
        self.rpm = None
        self.speedX = None
        self.speedY = None
        self.speedZ = None
        self.track = None
        self.trackPos = None
        self.wheelSpinVel = None
        self.z = None
        
        # Additional state tracking
        self.prev_speedX = None
        self.prev_angle = None
        self.prev_trackPos = None
    
    def setFromMsg(self, str_sensors):
        # Store previous values for derivative calculations
        if self.speedX is not None:
            self.prev_speedX = self.speedX
        if self.angle is not None:
            self.prev_angle = self.angle
        if self.trackPos is not None:
            self.prev_trackPos = self.trackPos
            
        self.sensors = self.parser.parse(str_sensors)
        
        self.setAngleD()
        self.setCurLapTimeD()
        self.setDamageD()
        self.setDistFromStartD()
        self.setDistRacedD()
        self.setFocusD()
        self.setFuelD()
        self.setGearD()
        self.setLastLapTimeD()
        self.setOpponentsD()
        self.setRacePosD()
        self.setRpmD()
        self.setSpeedXD()
        self.setSpeedYD()
        self.setSpeedZD()
        self.setTrackD()
        self.setTrackPosD()
        self.setWheelSpinVelD()
        self.setZD()
    
    def toMsg(self):
        self.sensors = {}
        
        self.sensors['angle'] = [self.angle]
        self.sensors['curLapTime'] = [self.curLapTime]
        self.sensors['damage'] = [self.damage]
        self.sensors['distFromStart'] = [self.distFromStart]
        self.sensors['distRaced'] = [self.distRaced]
        self.sensors['focus'] = self.focus
        self.sensors['fuel'] = [self.fuel]
        self.sensors['gear'] = [self.gear]
        self.sensors['lastLapTime'] = [self.lastLapTime]
        self.sensors['opponents'] = self.opponents
        self.sensors['racePos'] = [self.racePos]
        self.sensors['rpm'] = [self.rpm]
        self.sensors['speedX'] = [self.speedX]
        self.sensors['speedY'] = [self.speedY]
        self.sensors['speedZ'] = [self.speedZ]
        self.sensors['track'] = self.track
        self.sensors['trackPos'] = [self.trackPos]
        self.sensors['wheelSpinVel'] = self.wheelSpinVel
        self.sensors['z'] = [self.z]
        
        return self.parser.stringify(self.sensors)
    
    def getFloatD(self, name):
        try:
            val = self.sensors[name]
        except (KeyError, TypeError):
            val = None
        
        if val != None:
            try:
                val = float(val[0])
            except (ValueError, IndexError, TypeError):
                val = None
        
        return val
    
    def getFloatListD(self, name):
        try:
            val = self.sensors[name]
        except (KeyError, TypeError):
            val = None
        
        if val != None:
            try:
                l = []
                for v in val:
                    l.append(float(v))
                val = l
            except (ValueError, TypeError):
                val = None
        
        return val
    
    def getIntD(self, name):
        try:
            val = self.sensors[name]
        except (KeyError, TypeError):
            val = None
        
        if val != None:
            try:
                val = int(val[0])
            except (ValueError, IndexError, TypeError):
                val = None
        
        return val
    
    # Angle methods
    def setAngle(self, angle):
        self.angle = angle
    
    def setAngleD(self):        
        self.angle = self.getFloatD('angle')
        
    def getAngle(self):
        return self.angle
    
    # Current lap time methods
    def setCurLapTime(self, curLapTime):
        self.curLapTime = curLapTime
    
    def setCurLapTimeD(self):
        self.curLapTime = self.getFloatD('curLapTime')
    
    def getCurLapTime(self):
        return self.curLapTime
    
    # Damage methods
    def setDamage(self, damage):
        self.damage = damage
    
    def setDamageD(self):
        self.damage = self.getFloatD('damage')
        
    def getDamage(self):
        return self.damage
    
    # Distance from start methods
    def setDistFromStart(self, distFromStart):
        self.distFromStart = distFromStart
    
    def setDistFromStartD(self):
        self.distFromStart = self.getFloatD('distFromStart')
    
    def getDistFromStart(self):
        return self.distFromStart
    
    # Distance raced methods
    def setDistRaced(self, distRaced):
        self.distRaced = distRaced
    
    def setDistRacedD(self):
        self.distRaced = self.getFloatD('distRaced')
    
    def getDistRaced(self):
        return self.distRaced
    
    # Focus methods
    def setFocus(self, focus):
        self.focus = focus
    
    def setFocusD(self):
        self.focus = self.getFloatListD('focus')
    
    def getFocus(self):
        return self.focus
    
    # Fuel methods
    def setFuel(self, fuel):
        self.fuel = fuel
    
    def setFuelD(self):
        self.fuel = self.getFloatD('fuel')
    
    def getFuel(self):
        return self.fuel
    
    # Gear methods
    def setGear(self, gear):
        self.gear = gear
    
    def setGearD(self):
        self.gear = self.getIntD('gear')
    
    def getGear(self):
        return self.gear
    
    # Last lap time methods
    def setLastLapTime(self, lastLapTime):
        self.lastLapTime = lastLapTime
    
    def setLastLapTimeD(self):
        self.lastLapTime = self.getFloatD('lastLapTime')
    
    def getLastLapTime(self):
        return self.lastLapTime
    
    # Opponents methods
    def setOpponents(self, opponents):
        self.opponents = opponents
        
    def setOpponentsD(self):
        self.opponents = self.getFloatListD('opponents')
    
    def getOpponents(self):
        return self.opponents
    
    # Race position methods
    def setRacePos(self, racePos):
        self.racePos = racePos
    
    def setRacePosD(self):
        self.racePos = self.getIntD('racePos')
    
    def getRacePos(self):
        return self.racePos
    
    # RPM methods
    def setRpm(self, rpm):
        self.rpm = rpm
    
    def setRpmD(self):
        self.rpm = self.getFloatD('rpm')
    
    def getRpm(self):
        return self.rpm
    
    # Speed X methods
    def setSpeedX(self, speedX):
        self.speedX = speedX
    
    def setSpeedXD(self):
        self.speedX = self.getFloatD('speedX')
    
    def getSpeedX(self):
        return self.speedX
    
    # Speed Y methods
    def setSpeedY(self, speedY):
        self.speedY = speedY
    
    def setSpeedYD(self):
        self.speedY = self.getFloatD('speedY')
    
    def getSpeedY(self):
        return self.speedY
    
    # Speed Z methods
    def setSpeedZ(self, speedZ):
        self.speedZ = speedZ
    
    def setSpeedZD(self):
        self.speedZ = self.getFloatD('speedZ')
    
    def getSpeedZ(self):
        return self.speedZ
    
    # Track methods
    def setTrack(self, track):
        self.track = track
    
    def setTrackD(self):
        self.track = self.getFloatListD('track')
    
    def getTrack(self):
        return self.track
    
    # Track position methods
    def setTrackPos(self, trackPos):
        self.trackPos = trackPos
    
    def setTrackPosD(self):
        self.trackPos = self.getFloatD('trackPos')
    
    def getTrackPos(self):
        return self.trackPos
    
    # Wheel spin velocity methods
    def setWheelSpinVel(self, wheelSpinVel):
        self.wheelSpinVel = wheelSpinVel
    
    def setWheelSpinVelD(self):
        self.wheelSpinVel = self.getFloatListD('wheelSpinVel')
    
    def getWheelSpinVel(self):
        return self.wheelSpinVel
    
    # Z coordinate methods
    def setZ(self, z):
        self.z = z
    
    def setZD(self):
        self.z = self.getFloatD('z')
    
    def getZ(self):
        return self.z
    
    # Enhanced utility methods
    def getTotalSpeed(self):
        """Get total speed magnitude"""
        if self.speedX is None or self.speedY is None or self.speedZ is None:
            return 0.0
        try:
            return math.sqrt(self.speedX**2 + self.speedY**2 + self.speedZ**2)
        except (TypeError, ValueError):
            return 0.0
    
    def getAcceleration(self):
        """Calculate acceleration based on speed change"""
        if self.prev_speedX is None or self.speedX is None:
            return 0.0
        try:
            return self.speedX - self.prev_speedX
        except (TypeError, ValueError):
            return 0.0
    
    def getAngularVelocity(self):
        """Calculate angular velocity"""
        if self.prev_angle is None or self.angle is None:
            return 0.0
        try:
            return self.angle - self.prev_angle
        except (TypeError, ValueError):
            return 0.0
    
    def getTrackPositionChange(self):
        """Get change in track position"""
        if self.prev_trackPos is None or self.trackPos is None:
            return 0.0
        try:
            return self.trackPos - self.prev_trackPos
        except (TypeError, ValueError):
            return 0.0
    
    def isOnTrack(self):
        """Check if car is on track"""
        if self.trackPos is None:
            return True
        try:
            return abs(self.trackPos) <= 1.0
        except (TypeError, ValueError):
            return True
    
    def getTrackCurvature(self):
        """Estimate track curvature from sensors"""
        if not self.track or len(self.track) < 19:
            return 0.0
        
        try:
            left_avg = sum(self.track[:9]) / 9.0
            right_avg = sum(self.track[10:19]) / 9.0
            
            if left_avg + right_avg == 0:
                return 0.0
            return (right_avg - left_avg) / (right_avg + left_avg)
        except (TypeError, ValueError, ZeroDivisionError):
            return 0.0
    
    def getClosestOpponent(self):
        """Get information about closest opponent"""
        if not self.opponents or len(self.opponents) < 2:
            return None
        
        try:
            closest_distance = float('inf')
            closest_opponent = None
            
            for i in range(0, len(self.opponents), 2):
                if i + 1 < len(self.opponents):
                    distance = abs(self.opponents[i])
                    angle = self.opponents[i + 1]
                    
                    if distance < closest_distance:
                        closest_distance = distance
                        closest_opponent = {
                            'distance': distance,
                            'angle': angle,
                            'relative_position': self.opponents[i]  # Positive = ahead, negative = behind
                        }
            
            return closest_opponent
        except (TypeError, ValueError, IndexError):
            return None
    
    def isStuck(self):
        """Simple stuck detection"""
        try:
            return (self.getTotalSpeed() < 5.0 and 
                    self.rpm is not None and self.rpm > 3000)
        except (TypeError, ValueError):
            return False
    
    def getNearestTrackBoundary(self):
        """Get distance to nearest track boundary"""
        if not self.track:
            return 100.0
        try:
            return min(self.track)
        except (TypeError, ValueError):
            return 100.0
    
    def getOptimalGear(self):
        """Suggest optimal gear based on RPM"""
        if self.rpm is None or self.gear is None:
            return 1
        
        try:
            if self.rpm < 2000:
                return max(1, self.gear - 1)
            elif self.rpm > 7500:
                return min(6, self.gear + 1)
            else:
                return self.gear
        except (TypeError, ValueError):
            return 1
    
    def getStateSummary(self):
        """Get comprehensive state summary"""
        return {
            'speed': self.getTotalSpeed(),
            'position': self.trackPos,
            'angle': self.angle,
            'gear': self.gear,
            'rpm': self.rpm,
            'on_track': self.isOnTrack(),
            'race_position': self.racePos,
            'lap_time': self.curLapTime,
            'distance_raced': self.distRaced,
            'fuel': self.fuel,
            'stuck': self.isStuck()
        }