'''
Advanced AI Racing Driver for TORCS with Enhanced Neural Network and Adaptive Control
'''

import msgParser
import carState
import carControl
import math
import random
from collections import deque
import numpy as np

class EnhancedNeuralNetwork:
    """Enhanced neural network with multiple layers and training capability"""
    def __init__(self, input_size, hidden_size, output_size):
        # Initialize weights with Xavier/Glorot initialization
        self.weights1 = np.random.randn(hidden_size, input_size) * np.sqrt(2.0/input_size)
        self.weights2 = np.random.randn(output_size, hidden_size) * np.sqrt(2.0/hidden_size)
        self.biases1 = np.zeros(hidden_size)
        self.biases2 = np.zeros(output_size)
    
    def forward(self, inputs):
        """Forward pass through the network"""
        # Hidden layer with ReLU activation
        hidden = np.maximum(0, np.dot(self.weights1, inputs) + self.biases1)
        # Output layer with tanh activation
        outputs = np.tanh(np.dot(self.weights2, hidden) + self.biases2)
        return outputs
    
    def update_weights(self, reward, learning_rate=0.001):
        """Simple reinforcement learning weight update"""
        # This would be expanded with proper RL algorithm in production
        self.weights1 += learning_rate * reward * np.random.randn(*self.weights1.shape)
        self.weights2 += learning_rate * reward * np.random.randn(*self.weights2.shape)

class AdaptivePID:
    """PID controller with adaptive parameters"""
    def __init__(self, kp, ki, kd, max_output=1.0):
        self.base_kp = kp
        self.base_ki = ki
        self.base_kd = kd
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.max_output = max_output
        self.prev_error = 0
        self.integral = 0
        self.performance_history = []
    
    def update(self, error, dt=0.02):
        """Update controller with new error"""
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.prev_error = error
        return np.clip(output, -self.max_output, self.max_output)
    
    def adapt_parameters(self, performance_metric):
        """Adjust parameters based on performance"""
        self.performance_history.append(performance_metric)
        if len(self.performance_history) > 10:
            self.performance_history.pop(0)
        
        if len(self.performance_history) >= 5:
            improvement = (sum(self.performance_history[-3:]) - 
                         sum(self.performance_history[-6:-3])) / 3
            if improvement > 0:
                self.kp = min(self.base_kp * 1.5, self.kp * 1.05)
                self.ki = min(self.base_ki * 1.5, self.ki * 1.02)
            else:
                self.kp = max(self.base_kp * 0.5, self.kp * 0.95)
                self.ki = max(self.base_ki * 0.5, self.ki * 0.98)

class RacingLineOptimizer:
    """Optimal racing line calculation with learning"""
    def __init__(self):
        self.memory = {}
        self.current_track = None
        self.optimal_line = []
        self.current_position = 0
    
    def update_line(self, track_name, positions, speeds, lap_time):
        """Update racing line memory with successful laps"""
        if track_name not in self.memory:
            self.memory[track_name] = {'positions': [], 'speeds': [], 'best_time': float('inf')}
        
        if lap_time < self.memory[track_name]['best_time']:
            self.memory[track_name]['positions'] = positions
            self.memory[track_name]['speeds'] = speeds
            self.memory[track_name]['best_time'] = lap_time
    
    def get_optimal_position(self, track_sensors, speed, angle):
        """Get optimal position based on learned racing line"""
        if not track_sensors or len(track_sensors) < 19:
            return 0.0
        
        # If we have a learned line for this track section, use it
        if self.current_track in self.memory and self.optimal_line:
            return self.optimal_line[self.current_position % len(self.optimal_line)]
        
        # Fallback to geometric calculation
        left_avg = sum(track_sensors[:9]) / 9.0
        right_avg = sum(track_sensors[10:19]) / 9.0
        curvature = (right_avg - left_avg) / max(right_avg + left_avg, 1.0)
        
        # Basic racing line: outside-inside-outside
        if abs(curvature) > 0.1:
            return -0.3 if curvature > 0 else 0.3
        return curvature * 0.5

class Driver(object):
    '''Enhanced AI Racing Driver'''

    def __init__(self, stage):
        '''Constructor'''
        self.WARM_UP = 0
        self.QUALIFYING = 1
        self.RACE = 2
        self.UNKNOWN = 3
        self.stage = stage
        
        self.parser = msgParser.MsgParser()
        self.state = carState.CarState()
        self.control = carControl.CarControl()
        
        # Racing parameters
        self.steer_lock = 0.785398
        self.max_speed = 300
        self.prev_rpm = None
        self.stuck_counter = 0
        self.prev_distance = 0
        self.current_track = None
        
        # Enhanced AI Components
        self.steering_pid = AdaptivePID(kp=1.2, ki=0.1, kd=0.8, max_output=1.0)
        self.speed_pid = AdaptivePID(kp=0.8, ki=0.05, kd=0.3, max_output=1.0)
        self.racing_line = RacingLineOptimizer()
        self.decision_network = EnhancedNeuralNetwork(input_size=20, hidden_size=16, output_size=6)
        
        # Performance tracking
        self.lap_times = []
        self.sector_times = []
        self.best_lap_time = float('inf')
        self.last_lap_positions = []
        self.last_lap_speeds = []

    def init(self):
        '''Return init string with optimized rangefinder angles'''
        self.angles = [0 for x in range(19)]
        
        # Wide angle sensors for far vision
        for i in range(5):
            self.angles[i] = -90 + i * 15
            self.angles[18 - i] = 90 - i * 15
        
        # Medium angle sensors for cornering
        for i in range(5, 9):
            self.angles[i] = -20 + (i-5) * 5
            self.angles[18 - i] = 20 - (i-5) * 5
        
        return self.parser.stringify({'init': self.angles})

    def drive(self, msg):
        """Main driving logic with enhanced AI decision making"""
        self.state.setFromMsg(msg)
        
        # Track initialization
        if self.current_track is None and self.state.getTrack():
            self.current_track = hash(tuple(self.state.getTrack()))
        
        # Get current state
        speed = self.state.getSpeedX() or 0
        track_pos = self.state.getTrackPos() or 0
        angle = self.state.getAngle() or 0
        track_sensors = self.state.getTrack() or []
        opponents = self.state.getOpponents() or []
        
        # Check if stuck and handle recovery
        if self.is_stuck():
            self.handle_stuck_situation()
        else:
            # Enhanced racing logic
            self.enhanced_steering(track_sensors, speed, angle, track_pos, opponents)
            self.intelligent_gear_shifting()
            self.adaptive_speed_control(track_sensors, speed, opponents)
            
            # Record data for learning
            self.last_lap_positions.append(track_pos)
            self.last_lap_speeds.append(speed)
        
        # Update performance metrics
        self.update_performance_metrics()
        
        return self.control.toMsg()

    def enhanced_steering(self, track_sensors, speed, angle, track_pos, opponents):
        """Enhanced steering with neural network and learned racing line"""
        if not track_sensors:
            return
        
        # Get optimal racing line position
        target_pos = self.racing_line.get_optimal_position(track_sensors, speed, angle)
        
        # Prepare neural network inputs
        nn_inputs = self.prepare_neural_inputs(track_sensors, speed, angle, track_pos, opponents)
        
        # Get neural network decision
        nn_outputs = self.decision_network.forward(nn_inputs)
        steering_adjustment = nn_outputs[0]
        
        # Calculate steering error with multiple factors
        position_error = target_pos - track_pos
        angle_error = -angle * 0.5
        total_error = position_error + angle_error + steering_adjustment * 0.3
        
        # Apply adaptive PID control
        steering = self.steering_pid.update(total_error)
        
        # Speed-dependent steering sensitivity
        speed_factor = max(0.3, 1.0 - speed / 200.0)
        steering *= speed_factor
        
        self.control.setSteer(np.clip(steering, -1.0, 1.0))

    def prepare_neural_inputs(self, track_sensors, speed, angle, track_pos, opponents):
        """Prepare comprehensive inputs for neural network"""
        inputs = []
        
        # Normalized track sensors (11 key sensors)
        if track_sensors and len(track_sensors) >= 19:
            sensor_indices = [0, 2, 4, 6, 8, 9, 10, 12, 14, 16, 18]
            for i in sensor_indices:
                inputs.append(min(1.0, track_sensors[i] / 200.0))
        else:
            inputs.extend([0.5] * 11)
        
        # Additional inputs
        inputs.append(min(1.0, speed / 300.0))  # Speed
        inputs.append(angle / math.pi)  # Angle normalized to [-1,1]
        inputs.append(track_pos)  # Track position
        
        # Opponent information (if available)
        if opponents and len(opponents) >= 2:
            closest_opp = min(opponents[::2])
            inputs.append(min(1.0, closest_opp / 100.0))
            inputs.append(opponents[opponents.index(closest_opp)+1] / 180.0)
        else:
            inputs.extend([1.0, 0.0])  # No opponents
        
        # Car state
        inputs.append((self.state.getRpm() or 0) / 10000.0)
        inputs.append((self.state.getGear() or 1) / 6.0)
        
        # Ensure fixed input size
        while len(inputs) < 20:
            inputs.append(0.0)
        
        return inputs[:20]

    def intelligent_gear_shifting(self):
        """Enhanced gear shifting with track awareness"""
        rpm = self.state.getRpm()
        gear = self.state.getGear()
        speed = self.state.getSpeedX()
        
        if rpm is None or gear is None:
            return
        
        # Get track curvature
        track = self.state.getTrack()
        curvature = 0
        if track and len(track) >= 19:
            left_avg = sum(track[:9]) / 9.0
            right_avg = sum(track[10:19]) / 9.0
            curvature = (right_avg - left_avg) / max(right_avg + left_avg, 1.0)
        
        # Enhanced shifting logic considering track
        if gear <= 0:
            if speed > -5:
                gear = 1
        elif gear == 1:
            if rpm > (6000 if abs(curvature) < 0.1 else 6500) and speed > 20:
                gear = 2
        elif gear == 2:
            if rpm > (6500 if abs(curvature) < 0.1 else 7000) and speed > 40:
                gear = 3
            elif rpm < 2500 and speed < 25:
                gear = 1
        # ... (similar enhanced logic for other gears)
        
        self.control.setGear(max(1, min(6, gear)))
        self.prev_rpm = rpm

    def adaptive_speed_control(self, track_sensors, speed, opponents):
        """Adaptive speed control with opponent awareness"""
        if not track_sensors:
            return
        
        # Calculate safe speed based on track
        safe_speed = self.calculate_safe_speed(track_sensors)
        
        # Adjust for opponents
        safe_speed = self.adjust_speed_for_opponents(safe_speed, opponents)
        
        # PID control
        speed_error = safe_speed - (speed or 0)
        control_output = self.speed_pid.update(speed_error)
        
        if control_output > 0:
            self.control.setAccel(min(1.0, control_output))
            self.control.setBrake(0.0)
        else:
            self.control.setAccel(0.0)
            self.control.setBrake(min(1.0, -control_output))
        
        # Emergency braking
        if track_sensors[9] < 10:
            self.control.setAccel(0.0)
            self.control.setBrake(1.0)

    def calculate_safe_speed(self, track_sensors):
        """Calculate safe speed based on track geometry"""
        if len(track_sensors) < 19:
            return 100
        
        # Analyze track curvature
        center_dist = track_sensors[9]
        min_left = min(track_sensors[:9])
        min_right = min(track_sensors[10:19])
        track_width = min_left + min_right
        
        # Base safe speed on track geometry
        if center_dist < 30:
            return 60 + 30 * (track_width / 20.0)  # Adjust for track width
        elif center_dist < 60:
            return 120 + 50 * (track_width / 20.0)
        elif track_width < 15:
            return 100
        return 250

    def adjust_speed_for_opponents(self, base_speed, opponents):
        """Adjust speed based on opponent positions"""
        if not opponents:
            return base_speed
        
        # Find closest opponent ahead
        min_dist = float('inf')
        for i in range(0, len(opponents), 2):
            if i+1 < len(opponents) and 0 < opponents[i] < min_dist and abs(opponents[i+1]) < 30:
                min_dist = opponents[i]
        
        # Adjust speed based on proximity
        if min_dist < 20:
            return min(base_speed, 80)
        elif min_dist < 40:
            return min(base_speed, base_speed * 0.8)
        return base_speed

    def is_stuck(self):
        """Enhanced stuck detection"""
        speed = abs(self.state.getSpeedX() or 0) + abs(self.state.getSpeedY() or 0)
        distance = self.state.getDistRaced() or 0
        
        if self.prev_distance is not None:
            if abs(distance - self.prev_distance) < 1 and speed < 5:
                self.stuck_counter += 1
            else:
                self.stuck_counter = max(0, self.stuck_counter - 1)
        
        self.prev_distance = distance
        return self.stuck_counter > 25

    def handle_stuck_situation(self):
        """Enhanced stuck recovery"""
        if self.stuck_counter < 50:
            self.control.setGear(-1)
            self.control.setAccel(0.5)
            self.control.setSteer(-0.5 if self.stuck_counter % 20 < 10 else 0.5)
        else:
            self.control.setGear(1)
            self.control.setAccel(0.3)
            self.control.setSteer(1.0 if self.stuck_counter % 40 < 20 else -1.0)
        
        if self.stuck_counter > 100:
            self.stuck_counter = 0

    def update_performance_metrics(self):
        """Update learning and performance tracking"""
        current_lap_time = self.state.getCurLapTime()
        last_lap_time = self.state.getLastLapTime()
        
        if last_lap_time and last_lap_time > 0:
            if last_lap_time not in self.lap_times:
                self.lap_times.append(last_lap_time)
                
                # Update racing line memory with successful lap
                if len(self.last_lap_positions) > 10 and self.current_track:
                    self.racing_line.update_line(
                        self.current_track,
                        self.last_lap_positions,
                        self.last_lap_speeds,
                        last_lap_time)
                
                # Reset lap data
                self.last_lap_positions = []
                self.last_lap_speeds = []
                
                # Update neural network with reward
                reward = 1.0 if last_lap_time < (self.best_lap_time or float('inf')) else -0.5
                self.decision_network.update_weights(reward)
                
                if last_lap_time < (self.best_lap_time or float('inf')):
                    self.best_lap_time = last_lap_time
                    self.adapt_strategy()

    def adapt_strategy(self):
        """Adapt racing strategy based on performance"""
        if len(self.lap_times) > 3:
            recent_improvement = self.lap_times[-1] < self.lap_times[-2]
            if recent_improvement:
                self.steering_pid.adapt_parameters(1.0)
                self.speed_pid.adapt_parameters(1.0)
            else:
                self.steering_pid.adapt_parameters(-0.5)
                self.speed_pid.adapt_parameters(-0.5)

    def onShutDown(self):
        """Cleanup on shutdown"""
        print("Race finished. Best lap time: {}".format(self.best_lap_time))
        print("Total laps completed: {}".format(len(self.lap_times)))

    def onRestart(self):
        """Reset for new race"""
        self.stuck_counter = 0
        self.prev_distance = 0
        self.last_lap_positions = []
        self.last_lap_speeds = []
        # Reset controllers
        self.steering_pid.prev_error = 0
        self.steering_pid.integral = 0
        self.speed_pid.prev_error = 0
        self.speed_pid.integral = 0