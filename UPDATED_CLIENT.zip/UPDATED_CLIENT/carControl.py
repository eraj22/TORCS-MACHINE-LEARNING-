'''
Enhanced Car Control with validation and utility methods
'''
import msgParser

class CarControl(object):
    '''
    An object holding all the control parameters of the car with enhanced validation
    '''

    def __init__(self, accel=0.0, brake=0.0, gear=1, steer=0.0, clutch=0.0, focus=0, meta=0):
        '''Constructor'''
        self.parser = msgParser.MsgParser()
        
        self.actions = None
        
        # Initialize with validation
        self.setAccel(accel)
        self.setBrake(brake)
        self.setGear(gear)
        self.setSteer(steer)
        self.setClutch(clutch)
        self.focus = focus
        self.meta = meta
        
        # Control history for smoothing
        self.prev_accel = accel
        self.prev_brake = brake
        self.prev_steer = steer
    
    def toMsg(self):
        self.actions = {}
        
        self.actions['accel'] = [self.accel]
        self.actions['brake'] = [self.brake]
        self.actions['gear'] = [self.gear]
        self.actions['steer'] = [self.steer]
        self.actions['clutch'] = [self.clutch]
        self.actions['focus'] = [self.focus]
        self.actions['meta'] = [self.meta]
        
        return self.parser.stringify(self.actions)
    
    def setAccel(self, accel):
        """Set acceleration with validation and smoothing"""
        # Validate range [0, 1]
        accel = max(0.0, min(1.0, float(accel)))
        
        # Smooth acceleration changes to prevent jerky movements
        if hasattr(self, 'prev_accel'):
            max_change = 0.2  # Maximum change per step
            if abs(accel - self.prev_accel) > max_change:
                if accel > self.prev_accel:
                    accel = self.prev_accel + max_change
                else:
                    accel = self.prev_accel - max_change
        
        self.accel = accel
        self.prev_accel = accel
    
    def getAccel(self):
        return self.accel
    
    def setBrake(self, brake):
        """Set brake with validation and smoothing"""
        # Validate range [0, 1]
        brake = max(0.0, min(1.0, float(brake)))
        
        # Smooth brake changes
        if hasattr(self, 'prev_brake'):
            max_change = 0.3  # Allow faster braking than acceleration
            if abs(brake - self.prev_brake) > max_change:
                if brake > self.prev_brake:
                    brake = self.prev_brake + max_change
                else:
                    brake = self.prev_brake - max_change
        
        self.brake = brake
        self.prev_brake = brake
    
    def getBrake(self):
        return self.brake
    
    def setGear(self, gear):
        """Set gear with validation"""
        # Validate gear range [-1, 6] (reverse, neutral, 1-6 forward)
        gear = max(-1, min(6, int(gear)))
        
        # Prevent invalid gear transitions
        if hasattr(self, 'gear'):
            current_gear = self.gear
            # Don't allow jumping more than 1 gear at a time (except to/from reverse)
            if abs(gear - current_gear) > 1 and gear != -1 and current_gear != -1:
                if gear > current_gear:
                    gear = current_gear + 1
                else:
                    gear = current_gear - 1
        
        self.gear = gear
    
    def getGear(self):
        return self.gear
    
    def setSteer(self, steer):
        """Set steering with validation and smoothing"""
        # Validate range [-1, 1]
        steer = max(-1.0, min(1.0, float(steer)))
        
        # Smooth steering changes to prevent oscillation
        if hasattr(self, 'prev_steer'):
            max_change = 0.15  # Maximum steering change per step
            if abs(steer - self.prev_steer) > max_change:
                if steer > self.prev_steer:
                    steer = self.prev_steer + max_change
                else:
                    steer = self.prev_steer - max_change
        
        self.steer = steer
        self.prev_steer = steer
    
    def getSteer(self):
        return self.steer
    
    def setClutch(self, clutch):
        """Set clutch with validation"""
        # Validate range [0, 1]
        self.clutch = max(0.0, min(1.0, float(clutch)))
    
    def getClutch(self):
        return self.clutch
    
    def setMeta(self, meta):
        """Set meta command"""
        self.meta = int(meta)
    
    def getMeta(self):
        return self.meta
    
    def setFocus(self, focus):
        """Set focus direction"""
        self.focus = int(focus)
    
    def getFocus(self):
        return self.focus
    
    def emergencyBrake(self):
        """Apply emergency braking"""
        self.setAccel(0.0)
        self.setBrake(1.0)
    
    def fullAcceleration(self):
        """Apply full acceleration"""
        self.setAccel(1.0)
        self.setBrake(0.0)
    
    def neutralControls(self):
        """Set controls to neutral state"""
        self.setAccel(0.0)
        self.setBrake(0.0)
        self.setSteer(0.0)
        self.setClutch(0.0)
    
    def getControlSummary(self):
        """Get a summary of current control values"""
        return {
            'accel': self.accel,
            'brake': self.brake,
            'gear': self.gear,
            'steer': self.steer,
            'clutch': self.clutch
        }
    
    def isControlValid(self):
        """Check if all control values are within valid ranges"""
        return (0.0 <= self.accel <= 1.0 and
                0.0 <= self.brake <= 1.0 and
                -1 <= self.gear <= 6 and
                -1.0 <= self.steer <= 1.0 and
                0.0 <= self.clutch <= 1.0)